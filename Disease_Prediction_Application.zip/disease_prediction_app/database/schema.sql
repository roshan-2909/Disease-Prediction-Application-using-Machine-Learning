-- schema.sql
-- Database schema for the Disease Prediction Application
-- Stores user accounts and prediction history records

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS predictions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    disease_type TEXT NOT NULL CHECK (disease_type IN ('heart', 'diabetes', 'breast_cancer')),
    input_data TEXT NOT NULL,      -- JSON string of the submitted feature values
    result TEXT NOT NULL,          -- 'Positive' or 'Negative'
    probability REAL,              -- model confidence, if available
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
);

CREATE TABLE IF NOT EXISTS hospitals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    specialty TEXT NOT NULL,       -- 'Cardiology','Endocrinology','Oncology'
    city TEXT NOT NULL,
    rating REAL DEFAULT 4.0
);

-- Sample hospital data for the recommendation module (future work)
INSERT INTO hospitals (name, specialty, city, rating) VALUES
    ('City Heart Institute', 'Cardiology', 'Coimbatore', 4.6),
    ('Sunrise Cardiac Center', 'Cardiology', 'Coimbatore', 4.3),
    ('Metro Diabetes Care Clinic', 'Endocrinology', 'Coimbatore', 4.4),
    ('Wellness Endocrine Hospital', 'Endocrinology', 'Coimbatore', 4.1),
    ('Hope Cancer Care Centre', 'Oncology', 'Coimbatore', 4.7),
    ('Comprehensive Oncology Institute', 'Oncology', 'Coimbatore', 4.5);
