"""
generate_diagrams.py
Generates the System Architecture, Flowchart, and Module diagrams
for the Disease Prediction Application using Graphviz.
Run: python3 generate_diagrams.py   (outputs PNGs into this docs/ folder)
"""
import graphviz

# ---------------------------------------------------------------
# 1. SYSTEM ARCHITECTURE DIAGRAM
# ---------------------------------------------------------------
arch = graphviz.Digraph("architecture", format="png")
arch.attr(rankdir="LR", fontname="Helvetica", bgcolor="white")
arch.attr("node", shape="box", style="rounded,filled", fontname="Helvetica", fontsize="11")

arch.node("user", "User\n(Browser)", fillcolor="#DCEBFC")
arch.node("flask", "Flask Web App\n(app.py)", fillcolor="#D6F5E0")
arch.node("models", "Trained ML Models\n(joblib .sav files)", fillcolor="#FDEBD0")
arch.node("db", "SQLite Database\n(app.db)", fillcolor="#F9E0E0")
arch.node("data", "Datasets (CSV)\nheart / diabetes / breast_cancer", fillcolor="#EAEAEA")
arch.node("train", "Training Scripts\n(src/train_*.py)", fillcolor="#EAEAEA")

arch.edge("user", "flask", label="HTTP request\n(form submission)")
arch.edge("flask", "user", label="Rendered HTML\n(prediction result)")
arch.edge("flask", "models", label="load model /\npredict()")
arch.edge("flask", "db", label="log prediction /\nfetch hospitals")
arch.edge("data", "train", label="read CSV")
arch.edge("train", "models", label="save model\n(joblib.dump)")

arch.render("architecture_diagram", cleanup=True)

# ---------------------------------------------------------------
# 2. APPLICATION FLOWCHART
# ---------------------------------------------------------------
flow = graphviz.Digraph("flowchart", format="png")
flow.attr(rankdir="TB", fontname="Helvetica")
flow.attr("node", fontname="Helvetica", fontsize="11")

flow.node("start", "Start", shape="oval", style="filled", fillcolor="#DCEBFC")
flow.node("select", "User selects\ndisease module", shape="box", style="rounded,filled", fillcolor="#EAEAEA")
flow.node("input", "User enters\nclinical parameters", shape="parallelogram", style="filled", fillcolor="#EAEAEA")
flow.node("scale", "Input scaled using\nsaved StandardScaler", shape="box", style="rounded,filled", fillcolor="#EAEAEA")
flow.node("predict", "Trained model\npredicts outcome", shape="box", style="rounded,filled", fillcolor="#FDEBD0")
flow.node("decision", "Positive or\nNegative?", shape="diamond", style="filled", fillcolor="#F9E0E0")
flow.node("recommend", "Recommend nearby\nhospitals (by specialty)", shape="box", style="rounded,filled", fillcolor="#D6F5E0")
flow.node("log", "Log prediction to\nSQLite database", shape="box", style="rounded,filled", fillcolor="#EAEAEA")
flow.node("display", "Display result\nto the user", shape="box", style="rounded,filled", fillcolor="#EAEAEA")
flow.node("end", "End", shape="oval", style="filled", fillcolor="#DCEBFC")

flow.edge("start", "select")
flow.edge("select", "input")
flow.edge("input", "scale")
flow.edge("scale", "predict")
flow.edge("predict", "decision")
flow.edge("decision", "recommend", label="Positive")
flow.edge("decision", "log", label="Negative")
flow.edge("recommend", "log")
flow.edge("log", "display")
flow.edge("display", "end")

flow.render("flowchart_diagram", cleanup=True)

# ---------------------------------------------------------------
# 3. MODULE DIAGRAM
# ---------------------------------------------------------------
mod = graphviz.Digraph("modules", format="png")
mod.attr(rankdir="TB", fontname="Helvetica")
mod.attr("node", shape="box", style="rounded,filled", fontname="Helvetica", fontsize="11", fillcolor="#EAEAEA")

mod.node("app_module", "Disease Prediction Application")
mod.node("m1", "Data Module\n(collection & preprocessing)")
mod.node("m2", "Model Module\n(training, evaluation, persistence)")
mod.node("m3", "Web Module\n(Flask routes & templates)")
mod.node("m4", "Database Module\n(SQLite: users, predictions, hospitals)")
mod.node("m5", "Recommendation Module\n(hospital suggestion - rule-based,\ncollaborative filtering planned)")

mod.edge("app_module", "m1")
mod.edge("app_module", "m2")
mod.edge("app_module", "m3")
mod.edge("app_module", "m4")
mod.edge("app_module", "m5")
mod.edge("m1", "m2", label="clean data")
mod.edge("m2", "m3", label="model.sav")
mod.edge("m3", "m4", label="read/write")
mod.edge("m3", "m5", label="trigger on\npositive result")

mod.render("module_diagram", cleanup=True)

print("Diagrams generated: architecture_diagram.png, flowchart_diagram.png, module_diagram.png")
