# 15-Day Development Log — Template

> **How to use this document:** This is a study reference, not a finished
> diary. It maps the real project (in this repository) onto a 15-day
> structure so you can see what each stage involved. Before submitting
> anything, **go through each stage yourself** — run the code, read it,
> change a few values, re-train a model, and confirm you understand it.
> Then fill in your own dates and write the "Detailed Description" and
> "Skills Learned" sections in your own words, based on what you actually
> did. Submitting this without doing that would misrepresent the work as
> yours when it isn't yet — the fastest way to actually make it yours is to
> work through the stages below with the real code in front of you.

---

## Day 1 — Project Understanding & Environment Setup
**Date:** ______________
**Objective:** Understand the project scope and set up the development environment.
**Work Completed:** Read the project report; installed Python, VS Code, Git; created the project folder structure; initialized a virtual environment.
**Files Created:** `requirements.txt`, base folder structure (`data/`, `models/`, `src/`, `app/`, `database/`, `docs/`).
**Technologies Used:** Python 3, VS Code, Git, venv.
**Outcome:** Working local environment with all dependencies installed (`pip install -r requirements.txt` runs cleanly).
**Screenshot:** Terminal showing `pip install -r requirements.txt` completing successfully; VS Code with the project folder open.

## Day 2 — Dataset Collection & Exploration
**Date:** ______________
**Objective:** Source and explore the three disease datasets.
**Work Completed:** Downloaded the heart disease, diabetes, and breast cancer datasets into `data/`; loaded each with pandas; checked shape, data types, and missing values.
**Files Created/Modified:** `data/heart.csv`, `data/diabetes.csv`, `data/breast_cancer.csv`.
**Technologies Used:** Python, pandas.
**Outcome:** Confirmed dataset sizes — 303×14 (heart), 768×9 (diabetes), 569×31 (breast cancer) — with no missing values.
**Screenshot:** `data.info()` / `data.shape` output in a Python console for each dataset.

## Day 3 — Exploratory Data Analysis & Correlation
**Date:** ______________
**Objective:** Understand relationships between features and the target variable.
**Work Completed:** Computed Pearson correlation matrices; plotted heatmaps for each dataset; identified the strongest predictors (e.g. Glucose and BMI for diabetes).
**Files Created/Modified:** exploratory notebook/script (optional, based on `src/train_diabetes.py` correlation step).
**Technologies Used:** pandas, seaborn, matplotlib.
**Outcome:** Clear view of which features carry the most predictive signal for each disease.
**Screenshot:** Correlation heatmap for the diabetes dataset.

## Day 4 — Data Pre-processing Pipeline
**Date:** ______________
**Objective:** Build a repeatable pre-processing pipeline.
**Work Completed:** Wrote `src/utils.py` with shared helper functions (model saving, evaluation, plotting); implemented train/test split (80:20) and `StandardScaler` feature scaling for each dataset.
**Files Created/Modified:** `src/utils.py`.
**Technologies Used:** scikit-learn (`train_test_split`, `StandardScaler`).
**Outcome:** Reusable pre-processing utilities shared across all three training scripts.
**Screenshot:** `src/utils.py` open in the editor.

## Day 5 — Diabetes Prediction Model
**Date:** ______________
**Objective:** Train and compare classifiers for diabetes prediction.
**Work Completed:** Wrote `src/train_diabetes.py`; trained Logistic Regression, Decision Tree, Random Forest, SVM, and KNN; compared testing accuracy; selected the best model.
**Files Created/Modified:** `src/train_diabetes.py`, `models/Diabetes-pred_model.sav`, `models/Diabetes-scaler.sav`.
**Technologies Used:** scikit-learn, joblib.
**Outcome:** Logistic Regression selected as the best diabetes model (~82% testing accuracy in this run).
**Screenshot:** `docs/diabetes_accuracy_comparison.png`, terminal output of `python3 train_diabetes.py`.

## Day 6 — Heart Disease Prediction Model
**Date:** ______________
**Objective:** Train and compare classifiers for heart disease prediction.
**Work Completed:** Wrote `src/train_heart.py` following the same pattern as Day 5; compared all five algorithms on the heart disease dataset.
**Files Created/Modified:** `src/train_heart.py`, `models/Heart_Disease-pred_model.sav`, `models/Heart-scaler.sav`.
**Technologies Used:** scikit-learn, joblib.
**Outcome:** Best model selected for heart disease prediction (~87% testing accuracy in this run).
**Screenshot:** `docs/heart_accuracy_comparison.png`, `docs/heart_confusion_matrix.png`.

## Day 7 — Breast Cancer Prediction Model
**Date:** ______________
**Objective:** Train and compare classifiers for breast cancer prediction.
**Work Completed:** Wrote `src/train_breast_cancer.py`; encoded the diagnosis label; trained and compared all five algorithms on 30 diagnostic features.
**Files Created/Modified:** `src/train_breast_cancer.py`, `models/Breast_Cancer-pred_model.sav`, `models/BreastCancer-scaler.sav`.
**Technologies Used:** scikit-learn, joblib.
**Outcome:** Best model selected for breast cancer prediction (~98% testing accuracy in this run).
**Screenshot:** `docs/breast_cancer_accuracy_comparison.png`, `docs/breast_cancer_confusion_matrix.png`.

## Day 8 — Model Evaluation Deep-Dive
**Date:** ______________
**Objective:** Evaluate all three final models rigorously beyond raw accuracy.
**Work Completed:** Generated confusion matrices and classification reports (precision, recall, F1-score) for each model; saved evaluation plots into `docs/`.
**Files Created/Modified:** `docs/*_confusion_matrix.png` (×3).
**Technologies Used:** scikit-learn (`classification_report`, `confusion_matrix`), matplotlib, seaborn.
**Outcome:** Confirmed each model's strengths/weaknesses per class, not just overall accuracy.
**Screenshot:** Classification report printed in the terminal for each disease.

## Day 9 — Database Design
**Date:** ______________
**Objective:** Design the storage layer for user accounts, predictions, and hospital data.
**Work Completed:** Designed and wrote `database/schema.sql` (users, predictions, hospitals tables); seeded sample hospital data; built `database/app.db` from the schema.
**Files Created/Modified:** `database/schema.sql`, `database/app.db`.
**Technologies Used:** SQLite, SQL.
**Outcome:** Working relational database ready to log predictions and serve hospital recommendations.
**Screenshot:** Table list and sample rows from `app.db` (e.g. via a SQLite browser or `sqlite3` query output).

## Day 10 — Flask Application Skeleton
**Date:** ______________
**Objective:** Build the web application skeleton and load the trained models.
**Work Completed:** Wrote `app/app.py`; loaded all three models + scalers at startup; set up SQLite connection handling with Flask's `g` object.
**Files Created/Modified:** `app/app.py`.
**Technologies Used:** Flask.
**Outcome:** Flask app starts successfully and loads all models without error.
**Screenshot:** Terminal showing `python3 app.py` running on `http://127.0.0.1:5000`.

## Day 11 — Frontend: Home Page & Prediction Forms
**Date:** ______________
**Objective:** Build the user-facing pages for each prediction module.
**Work Completed:** Wrote `base.html`, `index.html`, `heart.html`, `diabetes.html`, `breast_cancer.html`, and `static/css/style.css`.
**Files Created/Modified:** `app/templates/*.html`, `app/static/css/style.css`.
**Technologies Used:** HTML, Jinja2, CSS.
**Outcome:** Fully styled, responsive prediction forms for all three diseases.
**Screenshot:** `screenshots/01_home.jpg`, `screenshots/02_heart_form.jpg`.

## Day 12 — Prediction Logic & Results Page
**Date:** ______________
**Objective:** Wire up form submission to the trained models and display results.
**Work Completed:** Implemented `/heart`, `/diabetes`, `/breast-cancer` POST routes; scaled input with the saved scaler; ran `model.predict()`; built `result.html` with a Positive/Negative badge.
**Files Created/Modified:** `app/app.py` (route logic), `app/templates/result.html`.
**Technologies Used:** Flask, scikit-learn, joblib.
**Outcome:** End-to-end prediction working from form submission to displayed result.
**Screenshot:** `screenshots/07_result_heart_positive.jpg`.

## Day 13 — Hospital Recommendation & History Log
**Date:** ______________
**Objective:** Add the hospital recommendation feature and prediction history view.
**Work Completed:** Implemented `recommend_hospitals()` querying the `hospitals` table by specialty; implemented `log_prediction()` to store every prediction; built `/history` route and `history.html`.
**Files Created/Modified:** `app/app.py`, `app/templates/history.html`.
**Technologies Used:** Flask, SQLite.
**Outcome:** Positive predictions now show relevant nearby hospitals; all predictions are logged and viewable.
**Screenshot:** `screenshots/10_history_populated.jpg`.

## Day 14 — Testing & Documentation
**Date:** ______________
**Objective:** Test the complete application and document the architecture.
**Work Completed:** Submitted sample predictions for all three modules and verified correct results; generated architecture, flowchart, and module diagrams (`docs/generate_diagrams.py`).
**Files Created/Modified:** `docs/architecture_diagram.png`, `docs/flowchart_diagram.png`, `docs/module_diagram.png`.
**Technologies Used:** Graphviz, manual + exploratory testing.
**Outcome:** Verified the app works end-to-end for all three diseases; visual documentation of the system complete.
**Screenshot:** `docs/flowchart_diagram.png`.

## Day 15 — Final Review & Packaging
**Date:** ______________
**Objective:** Finalize the project for submission.
**Work Completed:** Wrote `README.md` and installation guide; reviewed folder structure; re-ran all training scripts to confirm reproducibility; packaged the project.
**Files Created/Modified:** `README.md`, final repository cleanup.
**Technologies Used:** Git, Markdown.
**Outcome:** Complete, runnable, documented Disease Prediction Application ready for submission.
**Screenshot:** Final folder structure (`tree` output or file explorer view).

---

### Reminder
Fill in real dates and write each "Work Completed" / "Detailed Description"
section in your own words after you've actually run and understood that
day's code — that's what makes this an honest record of your internship
rather than a copy of this template.
