# Disease Prediction Application Using Machine Learning

A machine-learning-powered web application that predicts the likelihood of
**Heart Disease**, **Diabetes**, and **Breast Cancer** from patient clinical
data, and recommends nearby hospitals for positive results.

This implementation follows the project report: three classification
modules, each trained with five candidate algorithms (Logistic Regression,
Decision Tree, Random Forest, SVM, KNN), with the best-performing model per
disease deployed behind a Flask web interface.

---

## 1. Folder Structure

```
disease_prediction_app/
├── app/
│   ├── app.py                  # Flask application (routes + prediction logic)
│   ├── templates/               # Jinja2 HTML templates
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── heart.html
│   │   ├── diabetes.html
│   │   ├── breast_cancer.html
│   │   ├── result.html
│   │   └── history.html
│   └── static/
│       └── css/style.css
├── data/
│   ├── heart.csv                # 303 rows, 14 columns
│   ├── diabetes.csv             # 768 rows, 9 columns
│   └── breast_cancer.csv        # 569 rows, 31 columns
├── database/
│   ├── schema.sql                # table definitions + seed hospital data
│   └── app.db                    # SQLite database (auto-created from schema.sql)
├── models/                       # trained models + scalers (joblib .sav files)
│   ├── Heart_Disease-pred_model.sav
│   ├── Heart-scaler.sav
│   ├── Diabetes-pred_model.sav
│   ├── Diabetes-scaler.sav
│   ├── Breast_Cancer-pred_model.sav
│   └── BreastCancer-scaler.sav
├── src/
│   ├── utils.py                  # shared helper functions
│   ├── train_heart.py
│   ├── train_diabetes.py
│   └── train_breast_cancer.py
├── docs/
│   ├── generate_diagrams.py      # regenerates the 3 diagrams below
│   ├── architecture_diagram.png
│   ├── flowchart_diagram.png
│   ├── module_diagram.png
│   ├── *_confusion_matrix.png
│   └── *_accuracy_comparison.png
├── screenshots/                  # real captured screenshots of the running app
├── requirements.txt
└── README.md
```

---

## 2. Installation Guide

### Prerequisites
- Python 3.10+
- pip

### Steps

```bash
# 1. Clone / unzip the project and move into it
cd disease_prediction_app

# 2. Create and activate a virtual environment (recommended)
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Build the SQLite database (only needed once)
python3 -c "import sqlite3; c=sqlite3.connect('database/app.db'); c.executescript(open('database/schema.sql').read()); c.commit()"

# 5. Train the models (only needed once — pre-trained .sav files are already included)
cd src
python3 train_heart.py
python3 train_diabetes.py
python3 train_breast_cancer.py
cd ..

# 6. Run the web application
cd app
python3 app.py
```

The app will start at **http://127.0.0.1:5000**

---

## 3. How to Use

1. Open the home page and choose a disease module (Heart / Diabetes / Breast Cancer).
2. Fill in the clinical parameters shown on the form.
3. Click **Predict** — the model scales your input and returns **Positive** or **Negative**.
4. If the result is Positive, recommended hospitals for that specialty are shown.
5. Every prediction is logged to the database and viewable on the **History** page.

---

## 4. Datasets

| Dataset | Rows | Columns | Source |
|---|---|---|---|
| Heart Disease | 303 | 14 | UCI Heart Disease (Cleveland) |
| Diabetes | 768 | 9 | Pima Indians Diabetes Database |
| Breast Cancer | 569 | 31 | Wisconsin Diagnostic Breast Cancer (via scikit-learn) |

---

## 5. Model Results (this run)

| Disease | Best Algorithm | Testing Accuracy |
|---|---|---|
| Diabetes | Logistic Regression | ~82.5% |
| Heart Disease | Support Vector Machine | ~86.9% |
| Breast Cancer | Support Vector Machine | ~98.2% |

> Exact accuracy will vary slightly depending on the train/test split and
> library versions on your machine — re-run the training scripts to
> reproduce the figures in `docs/*_confusion_matrix.png` and
> `docs/*_accuracy_comparison.png`.

---

## 6. Diagrams

- `docs/architecture_diagram.png` — system architecture (browser ↔ Flask ↔ models ↔ database)
- `docs/flowchart_diagram.png` — end-to-end prediction workflow
- `docs/module_diagram.png` — application modules and their relationships

---

## 7. Future Work

- Hospital/doctor recommendation using **collaborative filtering** based on
  patient and guardian feedback (the `hospitals` table and rule-based
  recommendation in `app.py` are a placeholder for this).
- User authentication (the `users` table is already scaffolded in `schema.sql`).
- Model tuning via cross-validation and hyperparameter search.

---

## 8. Tech Stack

Python · Flask · scikit-learn · Pandas · NumPy · Matplotlib · Seaborn · SQLite · joblib
