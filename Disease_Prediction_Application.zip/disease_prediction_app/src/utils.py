"""
utils.py
Shared helper functions used by all three training scripts
(heart disease, diabetes, breast cancer).
"""

import os
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score

MODELS_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
DOCS_DIR = os.path.join(os.path.dirname(__file__), "..", "docs")


def save_model(model, filename):
    """Persist a trained model to the models/ directory using joblib."""
    os.makedirs(MODELS_DIR, exist_ok=True)
    path = os.path.join(MODELS_DIR, filename)
    joblib.dump(model, path)
    print(f"[saved] {path}")
    return path


def save_scaler(scaler, filename):
    os.makedirs(MODELS_DIR, exist_ok=True)
    path = os.path.join(MODELS_DIR, filename)
    joblib.dump(scaler, path)
    print(f"[saved] {path}")
    return path


def evaluate_and_report(name, y_test, y_pred):
    """Print accuracy + classification report, return accuracy score."""
    acc = accuracy_score(y_test, y_pred)
    print(f"\n{name}")
    print(confusion_matrix(y_test, y_pred))
    print(classification_report(y_test, y_pred))
    print(f"Testing Accuracy = {acc}")
    return acc


def save_confusion_matrix_plot(y_test, y_pred, title, filename):
    """Save a confusion-matrix heatmap image into docs/ (used for screenshots)."""
    os.makedirs(DOCS_DIR, exist_ok=True)
    cm = confusion_matrix(y_test, y_pred)
    plt.figure(figsize=(4.5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title(title)
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    path = os.path.join(DOCS_DIR, filename)
    plt.savefig(path, dpi=130)
    plt.close()
    print(f"[saved] {path}")
    return path


def save_accuracy_comparison_plot(results: dict, title, filename):
    """results: {'Logistic Regression': 0.79, 'Random Forest': 0.86, ...}"""
    os.makedirs(DOCS_DIR, exist_ok=True)
    plt.figure(figsize=(6, 4))
    names = list(results.keys())
    vals = [v * 100 for v in results.values()]
    bars = plt.bar(names, vals, color="#4C72B0")
    plt.ylabel("Testing Accuracy (%)")
    plt.title(title)
    plt.xticks(rotation=25, ha="right")
    plt.ylim(0, 100)
    for b, v in zip(bars, vals):
        plt.text(b.get_x() + b.get_width() / 2, v + 1, f"{v:.1f}%", ha="center", fontsize=8)
    plt.tight_layout()
    path = os.path.join(DOCS_DIR, filename)
    plt.savefig(path, dpi=130)
    plt.close()
    print(f"[saved] {path}")
    return path
