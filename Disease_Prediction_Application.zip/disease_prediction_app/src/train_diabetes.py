"""
train_diabetes.py
Trains and compares 5 classifiers on the Pima Indians Diabetes dataset,
selects Logistic Regression (best accuracy per the project report),
saves the final model + scaler for use by the Flask app.
"""

import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier

from utils import save_model, save_scaler, evaluate_and_report, save_confusion_matrix_plot, save_accuracy_comparison_plot

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "diabetes.csv")
COLUMNS = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin",
           "BMI", "DiabetesPedigreeFunction", "Age", "Outcome"]


def main():
    data = pd.read_csv(DATA_PATH, header=None, names=COLUMNS)
    print("Dataset size:", data.shape)

    x = data.iloc[:, 0:-1]
    y = data.iloc[:, -1]

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)

    sc = StandardScaler()
    x_train_s = sc.fit_transform(x_train)
    x_test_s = sc.transform(x_test)

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Decision Tree": DecisionTreeClassifier(random_state=0),
        "Random Forest": RandomForestClassifier(n_estimators=10, criterion="entropy", random_state=0),
        "Support Vector Machine": SVC(),
        "KNeighborsClassifier": KNeighborsClassifier(),
    }

    results = {}
    best_name, best_model, best_acc, best_pred = None, None, -1, None
    for name, model in models.items():
        model.fit(x_train_s, y_train)
        y_pred = model.predict(x_test_s)
        acc = evaluate_and_report(name, y_test, y_pred)
        results[name] = acc
        if acc > best_acc:
            best_name, best_model, best_acc, best_pred = name, model, acc, y_pred

    print(f"\nBest model: {best_name} with accuracy {best_acc:.4f}")

    save_model(best_model, "Diabetes-pred_model.sav")
    save_scaler(sc, "Diabetes-scaler.sav")
    save_confusion_matrix_plot(y_test, best_pred, f"Diabetes Prediction - {best_name}", "diabetes_confusion_matrix.png")
    save_accuracy_comparison_plot(results, "Diabetes Prediction - Algorithm Comparison", "diabetes_accuracy_comparison.png")


if __name__ == "__main__":
    main()
