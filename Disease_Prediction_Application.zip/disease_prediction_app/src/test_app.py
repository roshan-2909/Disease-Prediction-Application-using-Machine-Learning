"""
test_app.py
Basic sanity tests for the Disease Prediction Application.
Run: python3 test_app.py
Checks:
  1. All three trained models + scalers load correctly.
  2. Each model produces a valid prediction (0 or 1) on a sample input.
  3. The Flask app's routes respond with HTTP 200.
"""
import os
import sys
import joblib
import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
MODELS_DIR = os.path.join(ROOT, "models")


def test_models_load():
    files = [
        "Heart_Disease-pred_model.sav", "Heart-scaler.sav",
        "Diabetes-pred_model.sav", "Diabetes-scaler.sav",
        "Breast_Cancer-pred_model.sav", "BreastCancer-scaler.sav",
    ]
    for f in files:
        path = os.path.join(MODELS_DIR, f)
        assert os.path.exists(path), f"Missing model file: {f}"
        joblib.load(path)
    print("[PASS] All model/scaler files load correctly.")


def test_predictions():
    heart_fields = ["age", "sex", "cp", "trestbps", "chol", "fbs", "restecg",
                    "thalach", "exang", "oldpeak", "slope", "ca", "thal"]
    heart_model = joblib.load(os.path.join(MODELS_DIR, "Heart_Disease-pred_model.sav"))
    heart_scaler = joblib.load(os.path.join(MODELS_DIR, "Heart-scaler.sav"))
    sample = pd.DataFrame([[63, 1, 3, 145, 233, 1, 0, 150, 0, 2.3, 0, 0, 1]], columns=heart_fields)
    pred = heart_model.predict(heart_scaler.transform(sample))
    assert pred[0] in (0, 1)
    print(f"[PASS] Heart disease model prediction: {pred[0]}")

    diabetes_fields = ["Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
                        "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"]
    diabetes_model = joblib.load(os.path.join(MODELS_DIR, "Diabetes-pred_model.sav"))
    diabetes_scaler = joblib.load(os.path.join(MODELS_DIR, "Diabetes-scaler.sav"))
    sample = pd.DataFrame([[6, 148, 72, 35, 0, 33.6, 0.627, 50]], columns=diabetes_fields)
    pred = diabetes_model.predict(diabetes_scaler.transform(sample))
    assert pred[0] in (0, 1)
    print(f"[PASS] Diabetes model prediction: {pred[0]}")

    breast_fields = [
        "mean radius", "mean texture", "mean perimeter", "mean area", "mean smoothness",
        "mean compactness", "mean concavity", "mean concave points", "mean symmetry", "mean fractal dimension",
        "radius error", "texture error", "perimeter error", "area error", "smoothness error",
        "compactness error", "concavity error", "concave points error", "symmetry error", "fractal dimension error",
        "worst radius", "worst texture", "worst perimeter", "worst area", "worst smoothness",
        "worst compactness", "worst concavity", "worst concave points", "worst symmetry", "worst fractal dimension",
    ]
    breast_model = joblib.load(os.path.join(MODELS_DIR, "Breast_Cancer-pred_model.sav"))
    breast_scaler = joblib.load(os.path.join(MODELS_DIR, "BreastCancer-scaler.sav"))
    sample = pd.DataFrame([[17.99, 10.38, 122.8, 1001, 0.1184, 0.2776, 0.3001, 0.1471, 0.2419, 0.07871,
               1.095, 0.9053, 8.589, 153.4, 0.006399, 0.04904, 0.05373, 0.01587, 0.03003, 0.006193,
               25.38, 17.33, 184.6, 2019, 0.1622, 0.6656, 0.7119, 0.2654, 0.4601, 0.1189]], columns=breast_fields)
    pred = breast_model.predict(breast_scaler.transform(sample))
    assert pred[0] in (0, 1)
    print(f"[PASS] Breast cancer model prediction: {pred[0]}")


def test_flask_routes():
    import urllib.request
    base = "http://127.0.0.1:5000"
    for route in ["/", "/heart", "/diabetes", "/breast-cancer", "/history"]:
        try:
            with urllib.request.urlopen(base + route, timeout=5) as r:
                assert r.status == 200, f"{route} returned {r.status}"
                print(f"[PASS] GET {route} -> 200")
        except Exception as e:
            print(f"[SKIP] {route} -> Flask server not running ({e})")


if __name__ == "__main__":
    print("Running Disease Prediction Application test suite...\n")
    test_models_load()
    test_predictions()
    test_flask_routes()
    print("\nAll executable tests completed.")
